package DesignPatterns.Decorator.Pattern.CarService;

/**
 * Created by Rakshith on 4/19/2017.
 */
public interface CarService {
    public String getDescription();
    public int getCost();
}
