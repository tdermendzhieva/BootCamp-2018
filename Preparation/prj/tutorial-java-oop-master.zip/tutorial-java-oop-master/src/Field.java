/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Zattri
 */
public class Field {
    String name;
    int size;
    
    public Field(String fieldName, int fieldSize)  {
        name = fieldName;
        size = fieldSize;
    }
    
    public void waterField() {
    
    }
}
